#!/usr/bin/env python
# -*- coding: utf-8 -*--

# Copyright (c) 2023 Oracle and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl/

import importlib
import inspect
import os
import tempfile
from distutils import dir_util
from typing import Any, Dict, Union

import fsspec
from tabulate import tabulate

from ads.common import utils as ads_common_utils
from ads.common.decorator.runtime_dependency import (
    OptionalDependency,
    runtime_dependency,
)
from ads.opctl.cmds import _BackendFactory
from ads.opctl.config.base import ConfigProcessor
from ads.opctl.config.merger import ConfigMerger
from ads.opctl.constants import DEFAULT_ADS_CONFIG_FOLDER, RESOURCE_TYPE, RUNTIME_TYPE
from ads.opctl.utils import publish_image as publish_image_cmd
from ads.opctl.utils import run_command

from .__init__ import __operators__
from .common.utils import (
    _build_image,
    _convert_schema_to_html,
    _load_yaml_from_uri,
    _operator_info_list,
)

OPERATOR_BASE_IMAGE = "ads-operator-base"
OPERATOR_BASE_GPU_IMAGE = "ads-operator-gpu-base"
OPERATOR_BASE_DOCKER_FILE = "Dockerfile"
OPERATOR_BASE_DOCKER_GPU_FILE = "Dockerfile.gpu"


class OperatorNotFoundError(Exception):
    def __init__(self, operator: str):
        super().__init__(
            f"Operator with name: `{operator}` is not found."
            "Use `ads opctl mloperator list` to get the list of registered operators."
        )


def list() -> None:
    """
    Prints the list of the registered operators.
    """
    print(
        tabulate(
            (
                {
                    "Name": item.name,
                    "Version": item.version,
                    "Description": item.short_description,
                }
                for item in _operator_info_list()
            ),
            headers="keys",
        )
    )


def info(
    name: str,
    **kwargs: Dict[str, Any],
) -> None:
    """
    Prints the detailed information about the particular operator.

    Parameters
    ----------
    operator: str
        The name of the operator to generate the specification YAML.
    """
    operator_info = {item.name: item for item in _operator_info_list()}.get(name)
    if operator_info:
        print(operator_info.description)
    else:
        raise OperatorNotFoundError(name)


def init(
    name: str,
    output: Union[str, None] = None,
    overwrite: bool = False,
    ads_config: Union[str, None] = None,
    **kwargs: Dict[str, Any],
) -> None:
    """
    Generates a starter specification template YAML for the operator.

    Parameters
    ----------
    name: str
        The name of the operator to generate the specification YAML.
    output: (str, optional). Defaults to None.
        The path to the folder to save the resulting specification templates.
        The Tmp folder will be created in case when `output` is not provided.
    overwrite: (bool, optional). Defaults to False.
        Whether to overwrite the result specification YAML if exists.
    ads_config: (str, optional)
        The folder where the ads opctl config located.
    kwargs: (Dict, optional).
        Any optional kwargs arguments.

    Raises
    ------
    ValueError
        If `operator` not specified.
    OperatorNotFoundError
        If `operator` not found.
    """

    # validation
    if not name:
        raise ValueError(
            f"The `operator` attribute must be specified. Supported values: {__operators__}"
        )

    if name not in __operators__:
        raise OperatorNotFoundError(name)

    # generating operator specification
    operator_cmd_module = importlib.import_module(f"ads.mloperator.lowcode.{name}.cmd")
    importlib.reload(operator_cmd_module)
    operator_specification_template = getattr(operator_cmd_module, "init")(**kwargs)

    # create TMP folder if one is not provided by user
    if output:
        output = os.path.join(output, "")
        if ads_common_utils.is_path_exists(uri=output) and not overwrite:
            raise ValueError(
                f"The `{output}` already exists, use `--overwrite` option if you wish to overwrite."
            )
    else:
        overwrite = True
        output = os.path.join(tempfile.TemporaryDirectory().name, "")

    operator_path = os.path.join(os.path.dirname(__file__), "lowcode", name)

    with fsspec.open(os.path.join(output, f"{name}.YAML"), mode="w") as f:
        f.write(operator_specification_template)

    # save operator's schema in HTML format
    module_schema = _load_yaml_from_uri(os.path.join(operator_path, "schema.yaml"))
    with fsspec.open(os.path.join(output, "schema.html"), mode="w") as f:
        f.write(_convert_schema_to_html(name, module_schema))

    # copy README and original schema files into a destination folder
    for src_file in ("README.md", "schema.yaml"):
        ads_common_utils.copy_file(
            uri_src=os.path.join(operator_path, src_file),
            uri_dst=output,
            force_overwrite=overwrite,
        )

    # save supported backend specifications templates
    RUNTIME_TYPE_MAP = {
        RESOURCE_TYPE.JOB: [RUNTIME_TYPE.PYTHON, RUNTIME_TYPE.CONTAINER],
        RESOURCE_TYPE.DATAFLOW: [RUNTIME_TYPE.DATAFLOW],
    }
    for resource_type in RUNTIME_TYPE_MAP:
        for runtime_type in RUNTIME_TYPE_MAP[resource_type]:
            # get config info form INI files
            p = ConfigProcessor({"execution": {"backend": resource_type.value}}).step(
                ConfigMerger,
                ads_config=ads_config or DEFAULT_ADS_CONFIG_FOLDER,
                **kwargs,
            )
            # generate YAML specification template
            _BackendFactory(p.config).backend.init(
                uri=os.path.join(
                    output,
                    f"{resource_type.value.lower()}_{runtime_type.value.lower()}_config.YAML",
                ),
                overwrite=overwrite,
                runtime_type=runtime_type.value,
                **kwargs,
            )

    print("#" * 100)
    print("The auto-generated configs location: ", output)
    print("#" * 100)


@runtime_dependency(module="docker", install_from=OptionalDependency.OPCTL)
def build_image(
    name: str = None,
    source_folder: str = None,
    image: str = None,
    tag: str = None,
    gpu: bool = None,
    **kwargs: Dict[str, Any],
) -> None:
    """
    Builds image for the operator.
    For the built-in operators, the name needs to be provided.
    For the custom operators, the path (source_folder) to the operator needs to be provided.

    Parameters
    ----------
    name: (str, optional)
        Name of the service operator to build the image.
        Only relevant for built-in service operators.
    gpu: (bool, optional)
        Whether to build a GPU-enabled Docker image.
    source_folder: (str, optional)
        The folder containing the operator source code.
        Only relevant for custom operators.
    image: (optional, str)
        The name of the image. The operator name will be used if not provided.
    tag: (optional, str)
       The tag of the image. The `latest` will be used if not provided.

    Raises
    ------
    ValueError
        If neither `name` nor `source_folder` were provided.
    OperatorNotFoundError
        If the service operator not found.
    FileNotFoundError
        If source_folder not exists.
    """
    import docker

    operator_image_name = image

    if name:
        if name not in __operators__:
            raise OperatorNotFoundError(name)
        source_folder = os.path.dirname(
            inspect.getfile(importlib.import_module(f"ads.mloperator.lowcode.{name}"))
        )
        operator_image_name = operator_image_name or name
        print(f"Building Docker image for the `{name}` service operator.")
    elif source_folder:
        source_folder = os.path.abspath(os.path.expanduser(source_folder))
        if not os.path.isdir(source_folder):
            raise FileNotFoundError(f"The path {source_folder} does not exist")

        operator_image_name = operator_image_name or os.path.basename(
            source_folder.rstrip("/")
        )
        print(
            "Building Docker image for custom operator using source folder: "
            f"`{source_folder}`."
        )
    else:
        raise ValueError(
            "No operator name or source folder specified."
            "Please provide relevant options."
        )

    curr_dir = os.path.dirname(os.path.abspath(__file__))
    base_image_name = OPERATOR_BASE_GPU_IMAGE if gpu else OPERATOR_BASE_IMAGE

    try:
        client = docker.from_env()
        client.api.inspect_image(base_image_name)
    except docker.errors.ImageNotFound:
        print(f"Building base operator image {base_image_name}")

        base_docker_file = os.path.join(
            curr_dir,
            "docker",
            OPERATOR_BASE_DOCKER_GPU_FILE if gpu else OPERATOR_BASE_DOCKER_FILE,
        )

        result_image_name = _build_image(
            dockerfile=base_docker_file,
            image_name=base_image_name,
            target="base",
        )

        print(f"The base operator image `{result_image_name}` has been successfully built.")

    with tempfile.TemporaryDirectory() as td:
        dir_util.copy_tree(source_folder, os.path.join(td, "operator"), verbose=0)

        run_command = [
            f"FROM {base_image_name}",
            f"COPY ./operator/* $OPERATOR_DIR/",
        ]
        if os.path.exists(os.path.join(td, "operator", "environment.yaml")):
            run_command.append(
                f"RUN conda env update -f $OPERATOR_DIR/environment.yaml "
                "--name operator && conda clean -afy"
            )

        custom_docker_file = os.path.join(td, "Dockerfile")

        with open(custom_docker_file, "w") as f:
            f.writelines(run_command)

        result_image_name = _build_image(dockerfile=custom_docker_file, image_name=operator_image_name, tag=tag)

        print(f"The operator image `{result_image_name}` has been successfully built.")

    # print("#" * 100)
    # print("name", name)
    # print("source_folder", source_folder)
    # print("base_docker_file", base_docker_file)
    # print("base_image_name", base_image_name)
    # print("#" * 100)

    # build base image if doesn't exist
    # in case of built-in operator, the operator code no need to be copied to the container
    # in case of the custom operator, the source code needs to be copied to the container

    # print("#" * 100)
    # print(f"Builds  - {name}")
    # print("#" * 100)


def create(
    name: str,
    overwrite: bool = False,
    ads_config: Union[str, None] = None,
    **kwargs: Dict[str, Any],
) -> None:
    """
    Creates new operator.

    Parameters
    ----------
    name: str
        The name of the operator to generate the specification YAML.
    overwrite: (bool, optional). Defaults to False.
        Whether to overwrite the result specification YAML if exists.
    ads_config: (str, optional)
        The folder where the ads opctl config located.
    kwargs: (Dict, optional).
        Any optional kwargs arguments.
    """
    print("#" * 100)
    print(f"Creating new operator - {name}")
    print("#" * 100)
