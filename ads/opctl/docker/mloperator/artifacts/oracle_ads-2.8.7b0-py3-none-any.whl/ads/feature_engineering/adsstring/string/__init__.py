#!/usr/bin/env python
# -*- coding: utf-8 -*--

# Copyright (c) 2022 Oracle and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl/

# The ADSString was moved to the feature_type folder. This INI file created for the back compatability
from ads.feature_engineering.feature_type.adsstring.string import ADSString
