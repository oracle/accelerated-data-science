This is a sample metric markdown.
